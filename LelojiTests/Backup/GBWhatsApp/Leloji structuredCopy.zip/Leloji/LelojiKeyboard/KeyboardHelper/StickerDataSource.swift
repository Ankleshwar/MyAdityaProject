

import Foundation


public protocol StickerDataSource : class {
    
    var arrThumbnilData: NSMutableArray { get set }
	

	
    

}
