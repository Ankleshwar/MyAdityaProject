//
//  KeyboardViewController.swift
//  JimoniKeyboard
//
//  Created by Opiant on 04/04/18.
//  Copyright © 2018 Opiant. All rights reserved.
//

import UIKit
import MobileCoreServices

class ImageCollectionViewCell:UICollectionViewCell {
    @IBOutlet var imgView:UIImageView!
}


class KeyboardViewController: UIInputViewController{

    
    
    var heightConstraint: NSLayoutConstraint!
    @IBOutlet var collectionView: UICollectionView!
    
    var imgArray = NSMutableArray()
    
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        let nib = UINib(nibName: "KeyboardView", bundle: nil)
        let objects = nib.instantiate(withOwner: self, options: nil)
        view = objects[0] as! UIView;
        self.collectionView.register(UINib(nibName: "ImageCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ImageCollectionViewCell")
       
        
        for var i in 0...31
        {
            self.imgArray.add("a\(i).png")
        }

       
      
        
        self.collectionView.reloadData()
        self.view.bringSubview(toFront: self.collectionView);
        
  

    }
    
 
     func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.heightConstraint = NSLayoutConstraint(item:self.inputView!, attribute:.height, relatedBy:.equal, toItem:nil, attribute:.notAnAttribute, multiplier:0, constant:0)
        self.heightConstraint!.priority = UILayoutPriority(rawValue: 999)
        self.heightConstraint!.isActive = true
        self.inputView?.addConstraint(self.heightConstraint)
    }
    
    override func updateViewConstraints() {
        super.updateViewConstraints()
        
        guard self.heightConstraint != nil && self.view.frame.size.width != 0 && self.view.frame.size.height != 0 else { return }
        
        let portraitHeight: CGFloat = 400
        let landscapeHeight: CGFloat = 200
        let screenSize = UIScreen.main.bounds.size
        
        let newHeight = screenSize.width > screenSize.height ? landscapeHeight : portraitHeight
        
        if (self.heightConstraint!.constant != newHeight) {
            self.heightConstraint!.constant = newHeight
        }
    }

    
 
    @IBAction func returnPressed(_ sender: Any) {
        (textDocumentProxy as UIKeyInput).insertText("\n")
    }
    
    
    @IBAction func nextKeyboardPressed(_ sender: Any) {
          advanceToNextInputMode()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated
    }
    
    override func textWillChange(_ textInput: UITextInput?) {
        // The app is about to change the document's contents. Perform any preparation here.
    }
    

    
    


}

extension KeyboardViewController: UICollectionViewDelegate,UICollectionViewDataSource{
 
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.imgArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let iCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionViewCell", for: indexPath as IndexPath) as! ImageCollectionViewCell
        iCell.imgView.image = UIImage(named: self.imgArray.object(at: indexPath.row) as! String)
        if indexPath.row == 30 {
            let imgGIF = UIImage.gifImageWithName("a31")
            iCell.imgView .image = imgGIF
            
        }
//        else{
//            iCell.imgView.image = UIImage(named: self.imgArray.object(at: indexPath.row) as! String)
//        }
        
        return iCell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let pb = UIPasteboard.general
        if indexPath.row == 30 {
            let url: URL = Bundle.main.url(forResource: "a31", withExtension: ".gif")! as URL
            do {
                let imageData = try Data(contentsOf: url as URL)
                pb.setData(imageData , forPasteboardType: "com.compuserve.gif")
            } catch {
                print("Unable to load data: \(error)")
            }
        }
        else{
            let data = UIImagePNGRepresentation( UIImage(named: self.imgArray.object(at: indexPath.row) as! String)!)
            pb.setData(data!, forPasteboardType: kUTTypePNG as String)
        }
        
        
        
        
        
        let iCell = self.collectionView.cellForItem(at: indexPath as IndexPath) as! ImageCollectionViewCell
        UIView.animate(withDuration: 0.2, animations: {
            iCell.transform = CGAffineTransform(scaleX: 2.0, y: 2.0)
        }, completion: {(_) -> Void in
            iCell.transform =
                CGAffineTransform(scaleX: 1.0, y: 1.0)
        })
        (textDocumentProxy as UIKeyInput).insertText("")
        
    }
}

extension KeyboardViewController : UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
      //  let collectionViewWidth = collectionView.bounds.width
     
        
        return CGSize(width: 50 , height: 50)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
}

