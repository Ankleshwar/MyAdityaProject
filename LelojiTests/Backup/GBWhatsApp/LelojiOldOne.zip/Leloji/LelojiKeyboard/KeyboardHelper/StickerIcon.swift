

import UIKit


class StickerIcon: UICollectionViewCell {
    static let identifier = "StickerIcon"
    
    @IBOutlet weak var stickerImage: UIImageView!


    override func prepareForReuse() {
        super.prepareForReuse()
        
        self.stickerImage.image = nil
    }
	
	func configure(for sticker: String, inPack pack:Int) {
		
        if pack == 30 {
            self.stickerImage.image = UIImage.gifImageWithName(sticker)
        }
        else{
            self.stickerImage.image = UIImage(named: sticker)
        }
		
	}
}
